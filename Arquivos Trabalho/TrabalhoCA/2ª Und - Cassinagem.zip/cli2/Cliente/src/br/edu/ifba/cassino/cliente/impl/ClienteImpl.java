package br.edu.ifba.cassino.cliente.impl;

import br.edu.ifba.cassino.cliente.modelo.Jogador;
import com.github.javafaker.Faker;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class ClienteImpl implements Runnable {

    private final String mesaId;
    private final int capacidadeMesa;
    private final List<Jogador> jogadoresAtivos;
    private final Random random;

    public ClienteImpl(String mesaId, int capacidadeMesa) {
        this.mesaId = mesaId;
        this.capacidadeMesa = capacidadeMesa;
        this.jogadoresAtivos = new ArrayList<>();
        this.random = new Random();
    }

    @Override
    public void run() {
        Faker faker = new Faker(Locale.forLanguageTag("pt-BR"));

        while (true) {
            try {
                // Adiciona novos jogadores caso haja lugares disponíveis na mesa
                while (jogadoresAtivos.size() < capacidadeMesa) {
                    Jogador novoJogador = criarNovoJogador(faker);
                    jogadoresAtivos.add(novoJogador);
                    System.out.println("Novo jogador entrou na " + mesaId + ": " + novoJogador.getNome());
                }

                // Processa apostas dos jogadores ativos
                for (int i = 0; i < jogadoresAtivos.size(); i++) {
                    Jogador jogador = jogadoresAtivos.get(i);

                    // Realiza apostas para o jogador
                    realizarApostas(jogador);

                    // Verifica se o jogador terminou suas apostas
                    if (jogador.getTotalApostas() <= 0) {
                        jogador.setSaldoFinal(jogador.getSaldoAtual()); // Define o saldo final
                        enviarDadosJogadorAoServidor(jogador);
                        System.out.println("Jogador saiu da " + mesaId + ": " + jogador.getNome());
                        jogadoresAtivos.remove(i); // Remove o jogador da mesa
                        i--; // Ajusta o índice
                    }
                }

                // Aguarda um pouco antes de repetir o loop (simula o tempo das apostas)
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private Jogador criarNovoJogador(Faker faker) {
        String nome = faker.name().fullName();
        double saldoInicial = 500 + random.nextDouble() * 1500; // Saldo entre 500 e 2000
        int totalApostas = random.nextInt(16) + 10; // Entre 10 e 25 apostas
        return new Jogador(random.nextInt(1000), nome, saldoInicial, totalApostas);
    }

    private void realizarApostas(Jogador jogador) {
        // Simula apostas do jogador
        jogador.setTotalApostas(jogador.getTotalApostas() - 1); // Reduz o número de apostas
        double resultadoAposta = random.nextInt(21) - 10; // Gera um resultado aleatório entre -10 e 10
        jogador.setSaldoAtual(jogador.getSaldoAtual() + resultadoAposta); // Atualiza o saldo
        jogador.adicionarHistoricoAposta("Aposta/" + resultadoAposta); // Adiciona ao histórico
    }

    private void enviarDadosJogadorAoServidor(Jogador jogador) {
        // Simula o envio dos dados do jogador ao servidor
        System.out.println("Enviando dados do jogador " + jogador.getNome() + " da mesa " + mesaId);
        System.out.println("Saldo Inicial: " + jogador.getSaldoInicial());
        System.out.println("Saldo Final: " + jogador.getSaldoFinal());
        System.out.println("Histórico de Apostas: " + jogador.getHistoricoFormatado());
    }
}
