package br.edu.ifba.cassino.cliente.modelo;

import java.util.ArrayList;
import java.util.List;

public class Jogador {
    private int id;
    private String nome;
    private double saldoInicial;
    private double saldoAtual;
    private double saldoFinal;
    private int totalApostas;
    private List<String> historicoFormatado;
    private String mesaId;

    public Jogador(int id, String nome, double saldoInicial, int totalApostas) {
        this.id = id;
        this.nome = nome;
        this.saldoInicial = saldoInicial;
        this.saldoAtual = saldoInicial;
        this.saldoFinal = saldoInicial;
        this.totalApostas = totalApostas;
        this.historicoFormatado = new ArrayList<>();
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public double getSaldoInicial() {
        return saldoInicial;
    }

    public double getSaldoAtual() {
        return saldoAtual;
    }

    public void setSaldoAtual(double saldoAtual) {
        this.saldoAtual = Math.round(saldoAtual * 100.0) / 100.0; // Limita a 2 casas decimais
    }

    public double getSaldoFinal() {
        return saldoFinal;
    }

    public void setSaldoFinal(double saldoFinal) {
        this.saldoFinal = Math.round(saldoFinal * 100.0) / 100.0; // Limita a 2 casas decimais
    }

    public int getTotalApostas() {
        return totalApostas;
    }

    public void setTotalApostas(int totalApostas) {
        this.totalApostas = totalApostas;
    }

    public List<String> getHistoricoFormatado() {
        return historicoFormatado;
    }

    public void adicionarHistoricoAposta(String apostaFormatada) {
        historicoFormatado.add(apostaFormatada);
    }

    public String getMesaId() {
        return mesaId;
    }

    public void setMesaId(String mesaId) {
        this.mesaId = mesaId;
    }

    @Override
    public String toString() {
        return String.format(
                "Jogador{id=%d, nome='%s', saldoInicial=%.2f, saldoAtual=%.2f, saldoFinal=%.2f, totalApostas=%d, mesaId='%s'}",
                id, nome, saldoInicial, saldoAtual, saldoFinal, totalApostas, mesaId);
    }
}
