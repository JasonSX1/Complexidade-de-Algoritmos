package br.edu.ifba.cassino.cliente.impl;

import br.edu.ifba.cassino.cliente.modelo.Jogador;
import java.util.ArrayList;
import java.util.List;

public class OperacoesImpl {
    private final List<Jogador> jogadores;

    public OperacoesImpl() {
        this.jogadores = new ArrayList<>();
    }

    public void adicionarJogador(Jogador jogador) {
        jogadores.add(jogador);
    }

    public void processarApostas() {
        for (Jogador jogador : jogadores) {
            jogador.apostar();
        }
    }

    public List<Jogador> calcularMelhoresResultadosGruposDeTres() {
        List<Jogador> melhores = new ArrayList<>();
        List<Jogador> copiaJogadores = new ArrayList<>(jogadores);
        
        for (int i = 0; i < 3 && !copiaJogadores.isEmpty(); i++) {
            Jogador melhor = copiaJogadores.get(0);
            for (Jogador jogador : copiaJogadores) {
                if (jogador.getSaldo() > melhor.getSaldo()) {
                    melhor = jogador;
                }
            }
            melhores.add(melhor);
            copiaJogadores.remove(melhor);
        }
        return melhores;
    }

    public List<Jogador> getJogadores() {
        return jogadores;
    }
}
