package br.edu.ifba.cassino.cliente.util;

public class FalhaEncriptacao extends Exception {

    public FalhaEncriptacao(String mensagem) {
        super(mensagem);
    }
    
}
