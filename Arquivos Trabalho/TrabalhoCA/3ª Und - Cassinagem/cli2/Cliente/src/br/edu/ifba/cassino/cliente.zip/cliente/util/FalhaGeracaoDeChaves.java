package br.edu.ifba.cassino.cliente.util;

public class FalhaGeracaoDeChaves extends Exception {

    public FalhaGeracaoDeChaves(String mensagem) {
        super(mensagem);
    }
    
}
