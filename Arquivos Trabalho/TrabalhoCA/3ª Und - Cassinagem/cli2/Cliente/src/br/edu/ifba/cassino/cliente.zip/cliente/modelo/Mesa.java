package br.edu.ifba.cassino.cliente.modelo;

import br.edu.ifba.cassino.cliente.modelo.Jogador;
import br.edu.ifba.cassino.cliente.impl.OperacoesImpl;
import br.edu.ifba.cassino.cliente.comunicacao.ClienteHTTP;
import java.util.ArrayList;
import java.util.List;

public class Mesa extends Thread {
    private final int id;
    private final List<Jogador> jogadores;
    private final OperacoesImpl operacoes;
    private boolean ativa;

    public Mesa(int id, OperacoesImpl operacoes) {
        this.id = id;
        this.operacoes = operacoes;
        this.jogadores = new ArrayList<>();
        this.ativa = true;
    }

    public void adicionarJogador(Jogador jogador) {
        synchronized (jogadores) {
            jogadores.add(jogador);
        }
    }

    @Override
    public void run() {
        System.out.println("[MESA " + id + "] Iniciando...");
        while (ativa) {
            processarApostas();
            enviarResultadosAoServidor();
            renovarJogadores();
            try {
                Thread.sleep(5000); // Tempo entre levas de jogadores
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private void processarApostas() {
        synchronized (jogadores) {
            if (jogadores.isEmpty()) {
                System.out.println("[MESA " + id + "] Nenhum jogador presente para apostar.");
                return;
            }
            System.out.println("[MESA " + id + "] Processando apostas...");
            for (Jogador jogador : jogadores) {
                jogador.apostar(); // Aqui garantimos que as apostas sejam feitas
            }
        }
    }

    private void enviarResultadosAoServidor() {
        List<Jogador> melhores = operacoes.calcularMelhoresResultadosGruposDeTres();
        if (melhores.isEmpty()) {
            System.out.println("[MESA " + id + "] Nenhum jogador lucrativo para enviar ao servidor.");
        } else {
            System.out.println("[MESA " + id + "] Enviando melhores jogadores ao servidor: " + melhores);
            ClienteHTTP.enviarResultados(melhores);
        }
    }

    private void renovarJogadores() {
        synchronized (jogadores) {
            if (jogadores.isEmpty()) {
                System.out.println("[MESA " + id + "] Nenhum jogador para remover, aguardando nova leva.");
            } else {
                System.out.println("[MESA " + id + "] Renovando jogadores, removendo todos da mesa.");
                jogadores.clear(); // Apenas limpar os jogadores depois de processá-los corretamente
            }
        }
    }
}
