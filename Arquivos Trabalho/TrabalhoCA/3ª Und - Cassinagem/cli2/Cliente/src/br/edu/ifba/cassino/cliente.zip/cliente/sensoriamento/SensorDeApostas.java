package br.edu.ifba.cassino.cliente.sensoriamento;

import java.util.Random;
import com.github.javafaker.Faker;
import br.edu.ifba.cassino.cliente.modelo.Aposta;
import br.edu.ifba.cassino.cliente.modelo.Roleta;

public class SensorDeApostas {
    private static final Faker faker = new Faker();

    // Escolhe o tipo de aposta aleatoriamente com probabilidade controlada
    public static String escolherTipoAposta(Random random) {
        int tipo = faker.number().numberBetween(0, 100);
        if (tipo < 50) return "COR";      // 50% de chance de apostar na cor
        if (tipo < 80) return "PARIDADE"; // 30% de chance de apostar na paridade
        return "NUMERO";                  // 20% de chance de apostar em número
    }

    // Gera uma aposta do tipo NUMERO com Faker
    public static Aposta gerarApostaNumero(Roleta roleta, double entrada, Random random) {
        int numeroApostado = faker.number().numberBetween(0, 36);
        double resultado = (numeroApostado == roleta.getNumeroSorteado()) ? entrada * 3 : -entrada;
        return new Aposta(entrada, "NUMERO", numeroApostado, null, null,
                          roleta.getNumeroSorteado(), roleta.getCorSorteada(), roleta.getTipoSorteado(), resultado);
    }

    // Gera uma aposta do tipo COR com Faker
    public static Aposta gerarApostaCor(Roleta roleta, double entrada, Random random) {
        String corApostada = faker.options().option("VERMELHO", "PRETO");
        double resultado = (corApostada.equals(roleta.getCorSorteada())) ? entrada * 1.5 : -entrada;
        return new Aposta(entrada, "COR", -1, corApostada, null,
                          roleta.getNumeroSorteado(), roleta.getCorSorteada(), roleta.getTipoSorteado(), resultado);
    }

    // Gera uma aposta do tipo PARIDADE com Faker
    public static Aposta gerarApostaParidade(Roleta roleta, double entrada, Random random) {
        String paridadeApostada = faker.options().option("PAR", "ÍMPAR");
        double resultado = (paridadeApostada.equals(roleta.getTipoSorteado())) ? entrada * 1.5 : -entrada;
        return new Aposta(entrada, "PARIDADE", -1, null, paridadeApostada,
                          roleta.getNumeroSorteado(), roleta.getCorSorteada(), roleta.getTipoSorteado(), resultado);
    }

    // Método para formatar a linha de resultado de uma aposta - O(N)
    public static String formatarResultadoAposta(Aposta aposta, double saldoResultante) {
        final String VERDE = "\u001B[32m";
        final String VERMELHO = "\u001B[31m";
        final String RESET = "\u001B[0m";

        // Formatação condicional do resultado em cores
        String resultadoFormatado = (aposta.getResultado() >= 0 ? VERDE : VERMELHO) +
                String.format("%9.2f", aposta.getResultado()) + RESET;

        // Número da rodada com ajuste de alinhamento
        String numeroRodada = String.format("%2d", aposta.getNumeroDaRodada());

        // Ajuste para exibir zero à esquerda nos números da roleta e da aposta
        String numeroApostadoFormatado = aposta.getNumeroApostado() >= 0
                ? String.format("%02d", aposta.getNumeroApostado())
                : "--";

        // Ajuste do tamanho do tipo de aposta e valor de aposta para alinhamento
        String tipoApostaFormatado = String.format("%-7s", aposta.getTipoAposta());
        String apostaDetalheFormatado = aposta.getTipoAposta().equals("NUMERO") ? numeroApostadoFormatado
                : aposta.getTipoAposta().equals("COR") ? aposta.getCorApostada()
                : aposta.getParidadeApostada();

        // Retorna a linha formatada
        return String.format("%s     | %-8s | %7.2f | %-8s | %02d - %-8s - %-7s | %s | %14.2f",
                numeroRodada,
                tipoApostaFormatado,
                aposta.getEntrada(),
                apostaDetalheFormatado,
                aposta.getNumeroRoleta(),
                aposta.getCorRoleta(),
                aposta.getParidadeRoleta(),
                resultadoFormatado,
                saldoResultante);
    }
}