package br.edu.ifba.cassino.cliente.util;

import javax.crypto.Cipher;
import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class Encriptador {

    private static final String ALGORITMO_DE_ENCRIPTACAO = "RSA";

    /**
     * 🔑 Carrega a chave pública a partir de um arquivo.
     * @param caminhoArquivo Caminho do arquivo da chave pública.
     * @return Chave pública carregada.
     * @throws Exception Se houver erro ao carregar a chave.
     */
    public static PublicKey carregarChavePublica(String caminhoArquivo) throws Exception {
        File arquivo = new File(caminhoArquivo);
        byte[] bytesChave = Files.readAllBytes(Paths.get(arquivo.toURI()));

        X509EncodedKeySpec spec = new X509EncodedKeySpec(bytesChave);
        KeyFactory keyFactory = KeyFactory.getInstance(ALGORITMO_DE_ENCRIPTACAO);
        return keyFactory.generatePublic(spec);
    }

    /**
     * 🔒 Encripta os dados com a chave pública.
     * @param dados Dados a serem criptografados.
     * @param chavePublica Chave pública usada na encriptação.
     * @param chaveAleatoria Chave aleatória derivada do áudio.
     * @return Dados criptografados.
     * @throws Exception Se houver erro na encriptação.
     */
    public static byte[] encriptar(String dados, PublicKey chavePublica, byte[] chaveAleatoria) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITMO_DE_ENCRIPTACAO);
        cipher.init(Cipher.ENCRYPT_MODE, chavePublica);

        byte[] dadosBytes = dados.getBytes();
        byte[] dadosConcatenados = new byte[dadosBytes.length + chaveAleatoria.length];

        // 🔹 Concatenando chave aleatória ao início dos dados
        System.arraycopy(chaveAleatoria, 0, dadosConcatenados, 0, chaveAleatoria.length);
        System.arraycopy(dadosBytes, 0, dadosConcatenados, chaveAleatoria.length, dadosBytes.length);

        return cipher.doFinal(dadosConcatenados);
    }

    /**
     * 📌 Converte os dados encriptados para Base64 para envio seguro.
     * @param dadosEncriptados Dados criptografados.
     * @return String Base64 dos dados criptografados.
     */
    public static String converterParaBase64(byte[] dadosEncriptados) {
        return Base64.getEncoder().encodeToString(dadosEncriptados);
    }
}
