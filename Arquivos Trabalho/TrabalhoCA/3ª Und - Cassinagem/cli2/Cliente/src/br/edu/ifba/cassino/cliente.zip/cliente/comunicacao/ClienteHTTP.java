// Classe responsável pela comunicação do Cliente com o Servidor
package br.edu.ifba.cassino.cliente.comunicacao;

import br.edu.ifba.cassino.cliente.modelo.Jogador;
import com.google.gson.Gson;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class ClienteHTTP {
    private static final String URL_SERVIDOR = "http://localhost:8080/cassino/jogadores";
    private static final Gson gson = new Gson();

    public static void enviarResultados(List<Jogador> jogadores) {
        try {
            String jsonInput = gson.toJson(jogadores);
            URL url = new URL(URL_SERVIDOR);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json");
            con.setDoOutput(true);

            try (OutputStream os = con.getOutputStream()) {
                os.write(jsonInput.getBytes(StandardCharsets.UTF_8));
            }

            int responseCode = con.getResponseCode();
            System.out.println("[CLIENTE] Resposta do servidor: " + responseCode);
            con.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("[ERRO] Falha ao enviar resultados ao servidor.");
        }
    }
}
