// Classe principal do Cliente, garantindo a configuração e execução das mesas
package br.edu.ifba.cassino.cliente;

import br.edu.ifba.cassino.cliente.impl.OperacoesImpl;
import br.edu.ifba.cassino.cliente.modelo.Jogador;
import br.edu.ifba.cassino.cliente.modelo.Mesa;
import java.util.ArrayList;
import java.util.List;

public class App {
    private static final int QUANTIDADE_MESAS = 10; // Número de mesas fixas
    private static final int JOGADORES_POR_LEVA = 10; // Jogadores por leva

    public static void main(String[] args) {
        System.out.println("[CLIENTE] Iniciando Cassino...");
        OperacoesImpl operacoes = new OperacoesImpl();
        List<Mesa> mesas = new ArrayList<>();

        // Criando mesas
        for (int i = 0; i < QUANTIDADE_MESAS; i++) {
            Mesa mesa = new Mesa(i + 1, operacoes);
            mesas.add(mesa);
            mesa.start();
        }

        // Simulando entrada contínua de jogadores distribuindo corretamente entre as mesas
        int contadorJogador = 1;
        while (true) {
            for (int i = 0; i < JOGADORES_POR_LEVA; i++) {
                Jogador jogador = new Jogador(contadorJogador++, "Jogador", "Aleatorio", 1000.0);
                Mesa mesaEscolhida = mesas.get((contadorJogador - 1) % QUANTIDADE_MESAS); // Distribui jogadores entre as mesas
                mesaEscolhida.adicionarJogador(jogador);
                System.out.println("[APP] Jogador " + jogador.getNomeCompleto() + " adicionado à Mesa " + mesaEscolhida.getId());
            }
            try {
                Thread.sleep(10000); // Tempo entre novas levas de jogadores
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
